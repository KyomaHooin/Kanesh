ColorPy
=======

Physical color calculations in Python.

Version 0.1.1.
  Changes from 0.1.0:
    Various things I did on my local machine.
    A better shark fin plot, for example.
    Now on GitHub!

Version 0.1.0.
   I had this hosted at http://markkness.net
   (and still do) but GitHub is a better place for it now.

 