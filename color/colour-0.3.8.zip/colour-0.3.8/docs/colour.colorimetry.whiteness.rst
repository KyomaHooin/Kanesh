colour.colorimetry.whiteness Module
===================================

.. automodule:: colour.colorimetry.whiteness
    :members:
    :undoc-members:
    :show-inheritance:
