colour.models.cie_xyy Module
============================

.. automodule:: colour.models.cie_xyy
    :members:
    :undoc-members:
    :show-inheritance:
