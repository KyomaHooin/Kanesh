colour.colorimetry.cmfs Module
==============================

.. automodule:: colour.colorimetry.cmfs
    :members:
    :undoc-members:
    :show-inheritance:
