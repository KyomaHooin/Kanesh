colour.models.rgb.dataset.ntsc_rgb Module
=========================================

.. automodule:: colour.models.rgb.dataset.ntsc_rgb
    :members:
    :undoc-members:
    :show-inheritance:
