colour.models.hunter_lab Module
===============================

.. automodule:: colour.models.hunter_lab
    :members:
    :undoc-members:
    :show-inheritance:
