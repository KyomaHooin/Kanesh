colour.models.rgb.common Module
===============================

.. automodule:: colour.models.rgb.common
    :members:
    :undoc-members:
    :show-inheritance:
