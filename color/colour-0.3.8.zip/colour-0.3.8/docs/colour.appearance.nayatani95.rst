colour.appearance.nayatani95 Module
===================================

.. automodule:: colour.appearance.nayatani95
    :members:
    :undoc-members:
    :show-inheritance:
