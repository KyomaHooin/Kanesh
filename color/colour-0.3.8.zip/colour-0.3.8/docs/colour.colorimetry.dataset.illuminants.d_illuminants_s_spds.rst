colour.colorimetry.dataset.illuminants.d_illuminants_s_spds Module
==================================================================

.. automodule:: colour.colorimetry.dataset.illuminants.d_illuminants_s_spds
    :members:
    :undoc-members:
    :show-inheritance:
