colour.adaptation.dataset Package
=================================

Sub-Modules
-----------

.. toctree::

   colour.adaptation.dataset.cat

Module Contents
---------------

.. automodule:: colour.adaptation.dataset
    :members:
    :undoc-members:
    :show-inheritance:
