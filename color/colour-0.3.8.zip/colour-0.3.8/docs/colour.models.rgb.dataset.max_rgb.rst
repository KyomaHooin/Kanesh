colour.models.rgb.dataset.max_rgb Module
========================================

.. automodule:: colour.models.rgb.dataset.max_rgb
    :members:
    :undoc-members:
    :show-inheritance:
