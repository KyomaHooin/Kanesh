colour.models.rgb.derivation Module
===================================

.. automodule:: colour.models.rgb.derivation
    :members:
    :undoc-members:
    :show-inheritance:
