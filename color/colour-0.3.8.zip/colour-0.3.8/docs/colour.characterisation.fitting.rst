colour.characterisation.fitting Module
======================================

.. automodule:: colour.characterisation.fitting
    :members:
    :undoc-members:
    :show-inheritance:
