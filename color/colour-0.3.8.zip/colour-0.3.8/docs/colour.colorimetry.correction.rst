colour.colorimetry.correction Module
====================================

.. automodule:: colour.colorimetry.correction
    :members:
    :undoc-members:
    :show-inheritance:
