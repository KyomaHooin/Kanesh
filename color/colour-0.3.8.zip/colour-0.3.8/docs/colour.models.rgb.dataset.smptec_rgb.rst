colour.models.rgb.dataset.smptec_rgb Module
===========================================

.. automodule:: colour.models.rgb.dataset.smptec_rgb
    :members:
    :undoc-members:
    :show-inheritance:
