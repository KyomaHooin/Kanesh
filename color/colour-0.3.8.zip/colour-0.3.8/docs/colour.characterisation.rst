colour.characterisation Package
===============================

Sub-Packages
------------

.. toctree::

    colour.characterisation.dataset

Sub-Modules
-----------

.. toctree::

   colour.characterisation.displays
   colour.characterisation.fitting

Module Contents
---------------

.. automodule:: colour.characterisation
    :members:
    :undoc-members:
    :show-inheritance:
