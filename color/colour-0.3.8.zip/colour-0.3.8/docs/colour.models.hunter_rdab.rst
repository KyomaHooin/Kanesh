colour.models.hunter_rdab Module
================================

.. automodule:: colour.models.hunter_rdab
    :members:
    :undoc-members:
    :show-inheritance:
