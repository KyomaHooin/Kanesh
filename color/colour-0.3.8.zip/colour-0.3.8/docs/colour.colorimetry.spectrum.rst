colour.colorimetry.spectrum Module
==================================

.. automodule:: colour.colorimetry.spectrum
    :members:
    :undoc-members:
    :show-inheritance:
