colour.colorimetry.transformations Module
=========================================

.. automodule:: colour.colorimetry.transformations
    :members:
    :undoc-members:
    :show-inheritance:
