colour.models.rgb.dataset.beta_rgb Module
=========================================

.. automodule:: colour.models.rgb.dataset.beta_rgb
    :members:
    :undoc-members:
    :show-inheritance:
