colour.colorimetry.dataset.illuminants.spds Module
==================================================

.. automodule:: colour.colorimetry.dataset.illuminants.spds
    :members:
    :undoc-members:
    :show-inheritance:
