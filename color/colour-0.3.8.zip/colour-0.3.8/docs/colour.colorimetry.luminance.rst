colour.colorimetry.luminance Module
===================================

.. automodule:: colour.colorimetry.luminance
    :members:
    :undoc-members:
    :show-inheritance:
