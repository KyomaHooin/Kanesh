colour.colorimetry.blackbody Module
===================================

.. automodule:: colour.colorimetry.blackbody
    :members:
    :undoc-members:
    :show-inheritance:
