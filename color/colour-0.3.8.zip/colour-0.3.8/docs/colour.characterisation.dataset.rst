colour.characterisation.dataset Package
=======================================

Sub-Packages
------------

.. toctree::

    colour.characterisation.dataset.colour_checkers
    colour.characterisation.dataset.displays

Module Contents
---------------

.. automodule:: colour.characterisation.dataset
    :members:
    :undoc-members:
    :show-inheritance:
