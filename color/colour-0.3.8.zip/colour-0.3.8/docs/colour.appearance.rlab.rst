colour.appearance.rlab Module
=============================

.. automodule:: colour.appearance.rlab
    :members:
    :undoc-members:
    :show-inheritance:
