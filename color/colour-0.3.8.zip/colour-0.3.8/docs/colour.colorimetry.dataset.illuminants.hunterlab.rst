colour.colorimetry.dataset.illuminants.hunterlab Module
=======================================================

.. automodule:: colour.colorimetry.dataset.illuminants.hunterlab
    :members:
    :undoc-members:
    :show-inheritance:
