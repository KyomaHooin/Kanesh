colour.models.cie_lab Module
============================

.. automodule:: colour.models.cie_lab
    :members:
    :undoc-members:
    :show-inheritance:
