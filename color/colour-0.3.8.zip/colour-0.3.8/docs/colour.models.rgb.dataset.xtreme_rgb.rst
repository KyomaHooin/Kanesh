colour.models.rgb.dataset.xtreme_rgb Module
===========================================

.. automodule:: colour.models.rgb.dataset.xtreme_rgb
    :members:
    :undoc-members:
    :show-inheritance:
