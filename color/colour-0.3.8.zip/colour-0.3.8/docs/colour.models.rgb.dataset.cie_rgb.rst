colour.models.rgb.dataset.cie_rgb Module
========================================

.. automodule:: colour.models.rgb.dataset.cie_rgb
    :members:
    :undoc-members:
    :show-inheritance:
