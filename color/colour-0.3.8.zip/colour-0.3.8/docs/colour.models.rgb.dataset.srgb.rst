colour.models.rgb.dataset.srgb Module
=====================================

.. automodule:: colour.models.rgb.dataset.srgb
    :members:
    :undoc-members:
    :show-inheritance:
