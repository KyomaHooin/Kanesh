colour.models.rgb.dataset.best_rgb Module
=========================================

.. automodule:: colour.models.rgb.dataset.best_rgb
    :members:
    :undoc-members:
    :show-inheritance:
