colour.models.rgb.dataset.rimm_romm_rgb Module
==============================================

.. automodule:: colour.models.rgb.dataset.rimm_romm_rgb
    :members:
    :undoc-members:
    :show-inheritance:
