colour.models.rgb.dataset.don_rgb_4 Module
==========================================

.. automodule:: colour.models.rgb.dataset.don_rgb_4
    :members:
    :undoc-members:
    :show-inheritance:
