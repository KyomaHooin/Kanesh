colour.models.rgb.dataset.ekta_space_ps5 Module
===============================================

.. automodule:: colour.models.rgb.dataset.ekta_space_ps5
    :members:
    :undoc-members:
    :show-inheritance:
