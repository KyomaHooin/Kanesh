colour.corresponding.dataset.corresponding_chromaticities Module
================================================================

.. automodule:: colour.corresponding.dataset.corresponding_chromaticities
    :members:
    :undoc-members:
    :show-inheritance:
