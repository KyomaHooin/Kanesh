colour.colorimetry.dataset.illuminants.chromaticity_coordinates Module
======================================================================

.. automodule:: colour.colorimetry.dataset.illuminants.chromaticity_coordinates
    :members:
    :undoc-members:
    :show-inheritance:
