colour.models.rgb.rgb_colourspace Module
========================================

.. automodule:: colour.models.rgb.rgb_colourspace
    :members:
    :undoc-members:
    :show-inheritance:
