colour.constants.codata Module
==============================

.. automodule:: colour.constants.codata
    :members:
    :undoc-members:
    :show-inheritance:
