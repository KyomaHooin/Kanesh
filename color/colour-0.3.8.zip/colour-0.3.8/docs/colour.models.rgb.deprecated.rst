colour.models.rgb.deprecated Module
===================================

.. automodule:: colour.models.rgb.deprecated
    :members:
    :undoc-members:
    :show-inheritance:
