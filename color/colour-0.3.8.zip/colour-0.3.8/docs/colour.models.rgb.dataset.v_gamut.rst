colour.models.rgb.dataset.v_gamut Module
========================================

.. automodule:: colour.models.rgb.dataset.v_gamut
    :members:
    :undoc-members:
    :show-inheritance:
