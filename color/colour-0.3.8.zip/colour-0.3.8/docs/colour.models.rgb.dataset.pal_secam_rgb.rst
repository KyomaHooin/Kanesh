colour.models.rgb.dataset.pal_secam_rgb Module
==============================================

.. automodule:: colour.models.rgb.dataset.pal_secam_rgb
    :members:
    :undoc-members:
    :show-inheritance:
