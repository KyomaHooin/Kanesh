colour.corresponding.dataset Package
====================================

Sub-Modules
-----------

.. toctree::

   colour.corresponding.dataset.corresponding_chromaticities

Module Contents
---------------

.. automodule:: colour.corresponding.dataset
    :members:
    :undoc-members:
    :show-inheritance:
