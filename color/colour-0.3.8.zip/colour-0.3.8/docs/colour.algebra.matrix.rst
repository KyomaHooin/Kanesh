colour.algebra.matrix Module
============================

.. automodule:: colour.algebra.matrix
    :members:
    :undoc-members:
    :show-inheritance:
