colour.models.rgb.dataset.eci_rgb_v2 Module
===========================================

.. automodule:: colour.models.rgb.dataset.eci_rgb_v2
    :members:
    :undoc-members:
    :show-inheritance:
