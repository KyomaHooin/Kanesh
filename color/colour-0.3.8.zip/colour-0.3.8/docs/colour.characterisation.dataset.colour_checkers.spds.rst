colour.characterisation.dataset.colour_checkers.spds Module
===========================================================

.. automodule:: colour.characterisation.dataset.colour_checkers.spds
    :members:
    :undoc-members:
    :show-inheritance:
