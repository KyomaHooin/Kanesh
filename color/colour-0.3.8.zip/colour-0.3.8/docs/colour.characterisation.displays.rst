colour.characterisation.displays Module
=======================================

.. automodule:: colour.characterisation.displays
    :members:
    :undoc-members:
    :show-inheritance:
