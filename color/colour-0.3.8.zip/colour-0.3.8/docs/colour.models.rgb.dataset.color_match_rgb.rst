colour.models.rgb.dataset.color_match_rgb Module
================================================

.. automodule:: colour.models.rgb.dataset.color_match_rgb
    :members:
    :undoc-members:
    :show-inheritance:
