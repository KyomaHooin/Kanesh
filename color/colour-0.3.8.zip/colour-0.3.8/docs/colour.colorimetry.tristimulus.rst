colour.colorimetry.tristimulus Module
=====================================

.. automodule:: colour.colorimetry.tristimulus
    :members:
    :undoc-members:
    :show-inheritance:
