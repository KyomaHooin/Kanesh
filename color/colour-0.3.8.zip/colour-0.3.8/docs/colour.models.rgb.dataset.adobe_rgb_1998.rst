colour.models.rgb.dataset.adobe_rgb_1998 Module
===============================================

.. automodule:: colour.models.rgb.dataset.adobe_rgb_1998
    :members:
    :undoc-members:
    :show-inheritance:
