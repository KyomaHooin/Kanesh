colour.io.xrite Module
======================

.. automodule:: colour.io.xrite
    :members:
    :undoc-members:
    :show-inheritance:
