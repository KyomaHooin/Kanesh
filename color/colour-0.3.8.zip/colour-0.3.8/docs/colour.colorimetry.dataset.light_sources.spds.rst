colour.colorimetry.dataset.light_sources.spds Module
====================================================

.. automodule:: colour.colorimetry.dataset.light_sources.spds
    :members:
    :undoc-members:
    :show-inheritance:
