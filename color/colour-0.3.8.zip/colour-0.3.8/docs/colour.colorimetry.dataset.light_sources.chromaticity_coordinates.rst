colour.colorimetry.dataset.light_sources.chromaticity_coordinates Module
========================================================================

.. automodule:: colour.colorimetry.dataset.light_sources.chromaticity_coordinates
    :members:
    :undoc-members:
    :show-inheritance:
