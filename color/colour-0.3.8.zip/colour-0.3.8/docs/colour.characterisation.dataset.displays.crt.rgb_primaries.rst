colour.characterisation.dataset.displays.crt.rgb_primaries Module
=================================================================

.. automodule:: colour.characterisation.dataset.displays.crt.rgb_primaries
    :members:
    :undoc-members:
    :show-inheritance:
