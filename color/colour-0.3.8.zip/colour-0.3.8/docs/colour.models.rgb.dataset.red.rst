colour.models.rgb.dataset.red Module
====================================

.. automodule:: colour.models.rgb.dataset.red
    :members:
    :undoc-members:
    :show-inheritance:
