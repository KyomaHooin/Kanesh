colour.colorimetry.dataset.cmfs Module
======================================

.. automodule:: colour.colorimetry.dataset.cmfs
    :members:
    :undoc-members:
    :show-inheritance:
