colour.difference Package
=========================

Sub-Modules
-----------

.. toctree::

   colour.difference.delta_e

Module Contents
---------------

.. automodule:: colour.difference
    :members:
    :undoc-members:
    :show-inheritance:
