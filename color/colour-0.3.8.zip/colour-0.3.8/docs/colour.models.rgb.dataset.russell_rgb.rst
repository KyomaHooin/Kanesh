colour.models.rgb.dataset.russell_rgb Module
============================================

.. automodule:: colour.models.rgb.dataset.russell_rgb
    :members:
    :undoc-members:
    :show-inheritance:
