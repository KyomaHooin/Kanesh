colour.difference.delta_e Module
================================

.. automodule:: colour.difference.delta_e
    :members:
    :undoc-members:
    :show-inheritance:
