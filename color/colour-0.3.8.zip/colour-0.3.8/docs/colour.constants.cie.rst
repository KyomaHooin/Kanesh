colour.constants.cie Module
===========================

.. automodule:: colour.constants.cie
    :members:
    :undoc-members:
    :show-inheritance:
