colour.models.dataset.pointer_gamut Module
==========================================

.. automodule:: colour.models.dataset.pointer_gamut
    :members:
    :undoc-members:
    :show-inheritance:
