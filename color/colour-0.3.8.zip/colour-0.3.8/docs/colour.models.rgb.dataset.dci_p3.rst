colour.models.rgb.dataset.dci_p3 Module
=======================================

.. automodule:: colour.models.rgb.dataset.dci_p3
    :members:
    :undoc-members:
    :show-inheritance:
