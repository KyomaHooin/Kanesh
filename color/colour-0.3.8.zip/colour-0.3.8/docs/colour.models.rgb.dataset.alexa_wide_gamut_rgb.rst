colour.models.rgb.dataset.alexa_wide_gamut_rgb Module
=====================================================

.. automodule:: colour.models.rgb.dataset.alexa_wide_gamut_rgb
    :members:
    :undoc-members:
    :show-inheritance:
