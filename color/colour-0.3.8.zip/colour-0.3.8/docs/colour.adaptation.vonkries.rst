colour.adaptation.vonkries Module
=================================

.. automodule:: colour.adaptation.vonkries
    :members:
    :undoc-members:
    :show-inheritance:
