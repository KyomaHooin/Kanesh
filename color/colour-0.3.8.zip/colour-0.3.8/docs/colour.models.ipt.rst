colour.models.ipt Module
========================

.. automodule:: colour.models.ipt
    :members:
    :undoc-members:
    :show-inheritance:
