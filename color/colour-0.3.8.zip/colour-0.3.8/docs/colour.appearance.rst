colour.appearance Package
=========================

Sub-Modules
-----------

.. toctree::

   colour.appearance.atd95
   colour.appearance.ciecam02
   colour.appearance.hunt
   colour.appearance.llab
   colour.appearance.nayatani95
   colour.appearance.rlab

Module Contents
---------------

.. automodule:: colour.appearance
    :members:
    :undoc-members:
    :show-inheritance:
