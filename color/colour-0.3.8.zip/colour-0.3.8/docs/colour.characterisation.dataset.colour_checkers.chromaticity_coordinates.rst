colour.characterisation.dataset.colour_checkers.chromaticity_coordinates Module
===============================================================================

.. automodule:: colour.characterisation.dataset.colour_checkers.chromaticity_coordinates
    :members:
    :undoc-members:
    :show-inheritance:
