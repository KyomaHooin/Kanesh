colour.models.rgb.dataset.cinema_gamut Module
=============================================

.. automodule:: colour.models.rgb.dataset.cinema_gamut
    :members:
    :undoc-members:
    :show-inheritance:
