colour.models.common Module
===========================

.. automodule:: colour.models.common
    :members:
    :undoc-members:
    :show-inheritance:
