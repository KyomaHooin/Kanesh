colour.colorimetry.dataset.illuminants Package
==============================================

Sub-Modules
-----------

.. toctree::

   colour.colorimetry.dataset.illuminants.chromaticity_coordinates
   colour.colorimetry.dataset.illuminants.d_illuminants_s_spds
   colour.colorimetry.dataset.illuminants.hunterlab
   colour.colorimetry.dataset.illuminants.spds

Module Contents
---------------

.. automodule:: colour.colorimetry.dataset.illuminants
    :members:
    :undoc-members:
    :show-inheritance:
