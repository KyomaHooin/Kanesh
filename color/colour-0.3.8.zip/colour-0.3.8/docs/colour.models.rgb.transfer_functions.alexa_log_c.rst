colour.models.rgb.transfer_functions.alexa_log_c Module
=======================================================

.. automodule:: colour.models.rgb.transfer_functions.alexa_log_c
    :members:
    :undoc-members:
    :show-inheritance:
