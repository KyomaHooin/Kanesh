Contributing
============

Contributing to Colour
----------------------

If you would like to contribute to **Colour**, please refer to the following guide: http://colour-science.org/contributing/

About
-----

| **Colour** by Colour Developers - 2013-2016
| Copyright © 2013-2016 – Colour Developers – `colour-science@googlegroups.com <colour-science@googlegroups.com>`_
| This software is released under terms of New BSD License: http://opensource.org/licenses/BSD-3-Clause
| `http://github.com/colour-science/colour <http://github.com/colour-science/colour>`_
