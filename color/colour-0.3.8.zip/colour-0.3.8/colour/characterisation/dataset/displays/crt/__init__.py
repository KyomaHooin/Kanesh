#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import

from .rgb_primaries import CRT_DISPLAYS_RGB_PRIMARIES

__all__ = ['CRT_DISPLAYS_RGB_PRIMARIES']
