#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import

from .optimal_colour_stimuli import ILLUMINANTS_OPTIMAL_COLOUR_STIMULI

__all__ = ['ILLUMINANTS_OPTIMAL_COLOUR_STIMULI']
