#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import

from .smits1999 import SMITS_1999_SPDS

__all__ = ['SMITS_1999_SPDS']
