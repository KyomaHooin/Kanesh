This is a plotting library for use with matplotlib to make ternary plots, including heatmaps.
